package testing;

import MillionaireGame.UserDatabase;
import MillionaireGame.QuestionManager;
import MillionaireGame.GameManager;
import MillionaireGame.DatabaseManager;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class DatabaseManagerTest {

    public DatabaseManager databaseManager;
    public GameManager gameManager;
    public UserDatabase userDatabase;
    public QuestionManager questionManager;

    
    @Before
    public void setUp() {
        this.userDatabase = new UserDatabase();
        this.userDatabase.playerDbSetup();
        this.databaseManager = new DatabaseManager();
        this.gameManager = new GameManager();
        this.questionManager = new QuestionManager();
        this.questionManager.databaseSetUp();
    }

    @Test
    public void testCheckNameForValidRecord() {
        System.out.println("checkName");
        String username = "x";
        String password = "x";
        this.gameManager = this.userDatabase.checkName(username, password);
        boolean result = gameManager.getHasLogin();
        boolean expResult = true;
        assertEquals(expResult, result);
    }



    @Test
    public void testCheckNameForUserNotInRecord() {
        System.out.println("newUser");
        String username = "someRandomUsernameInput";
        String password = "RandomPassword";
        this.gameManager = this.userDatabase.checkName(username, password);
        boolean result = gameManager.getHasLogin();
        boolean expResult = false;
        assertEquals(expResult, result);
    }
    
    @Test
    public void testCheckNameForValidUsernameButInvalidPassoword() {
        String username = "a";
        String password = "b";
        System.out.println("newUser");

        this.gameManager = this.userDatabase.checkName(username, password);
        boolean result = gameManager.getHasLogin();
        boolean expResult = false;
        assertEquals(expResult, result);
    }
}
