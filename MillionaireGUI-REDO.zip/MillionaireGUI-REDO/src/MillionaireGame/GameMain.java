package MillionaireGame;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class GameMain {
    //Game main class creates instances and runs program
    GameMain(){
        try {
            DatabaseManager dm = new DatabaseManager();
            UImanager uiManager = new UImanager();

            ButtonControl bc = new ButtonControl(uiManager, dm);
            
            dm.addObserver(uiManager);
        } catch (IOException ex) {
            Logger.getLogger(GameMain.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public static void main(String[] args){
        GameMain game = new GameMain();  
    }
}
