package MillionaireGame;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class QuestionManager {
    //QuestionManager clas connects to question database and sets each questions answers and lifelines
    String user = "pdc";
    String password = "pdc";
    String url = "jdbc:derby:QuestionDB;create=true";
    Connection conn = null;
    Statement statement = null;
    final int NO_OF_ANSWERS = 4; 

    //setting up database
    public void databaseSetUp() 
    {
        try 
        {
            conn = DriverManager.getConnection(url, user, password);
            statement = conn.createStatement();
            String tableName = "Question";
            if (!checkForTable(tableName)) 
            {
                //create table
                statement.executeUpdate("CREATE TABLE " + tableName + " (questionno INT,question VARCHAR(200), correctanswer INT, a0 VARCHAR(200),a1 VARCHAR(200),a2 VARCHAR(200),a3 VARCHAR(200))");
                this.readFileToDatabase();
            } else
            {
                statement.executeUpdate("DELETE FROM Question");
                this.readFileToDatabase();
            }
        } catch (IOException | SQLException e) 
        {
            System.out.println("Exception Error");
        }
    }

    public void readFileToDatabase() throws IOException, SQLException
    {
        try 
        {
            BufferedReader bufferReader;
            Scanner scan;
            
            String question;
            String correctAnswer;
            String[] answers = new String[NO_OF_ANSWERS];
            int cAnswer;

            int counter = 1;
            try (FileReader fileScan = new FileReader("src/MillionaireGame/Questions.txt")) 
            {
                bufferReader = new BufferedReader(fileScan);
                scan = new Scanner(bufferReader);
                do 
                {
                    question = scan.nextLine();
                    correctAnswer = scan.nextLine();
                    cAnswer = Integer.parseInt(correctAnswer);
                    for (int j = 0; j < answers.length; j++) 
                    {
                        answers[j] = scan.nextLine();
                    }
                    statement.addBatch("INSERT INTO Question VALUES(" + counter + ",'" + question + "'," + cAnswer + ",'" + answers[0] + "','" + answers[1] + "','" + answers[2] + "','" + answers[3] + "')");
                    statement.executeBatch();
                    counter++;
                    answers = new String[NO_OF_ANSWERS];
                } while (scan.hasNext());
            }
            bufferReader.close();
            scan.close();
        } catch (FileNotFoundException e) 
        {
            System.out.println("File not found");
        }
    }
    
        private boolean checkForTable(String newTableName) 
    {
        boolean flag = false;
        try 
        {
            System.out.println("Scaning for tables");
            String[] types = {"TABLE"};
            DatabaseMetaData dbmd = conn.getMetaData();
            ResultSet rsDBMeta = dbmd.getTables(null, null, null, null);
            while (rsDBMeta.next()) 
            {
                String tableName = rsDBMeta.getString("TABLE_NAME");
                if (tableName.compareToIgnoreCase(newTableName) == 0)
                {
                    System.out.println(tableName + " table found");
                    flag = true;
                }
            }
            if (rsDBMeta != null)
            {
                rsDBMeta.close();
            }
        } catch (SQLException ex) 
        {
            Logger.getLogger(QuestionManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    public void newQuestion(GameManager qData) 
    {
        try 
        {
            ResultSet rs = statement.executeQuery("SELECT question , correctanswer, a0, a1 ,a2,a3 FROM Question WHERE questionno =" + qData.getCurrentQuestion());
            if (rs.next()) 
            {
                qData.setQuestion(rs.getString("question"));
                qData.getChoices()[0] = rs.getString("a0");
                qData.getChoices()[1] = rs.getString("a1");
                qData.getChoices()[2] = rs.getString("a2");
                qData.getChoices()[3] = rs.getString("a3");
                qData.setCorrectAns(rs.getInt("correctanswer"));
            }
        } catch (SQLException ex) 
        {
            Logger.getLogger(QuestionManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void fiftyFifty(GameManager gm) 
    {
        int[] ans = new int[gm.getChoices().length];
        int[] falseAns = new int[gm.getChoices().length];
        Random rand = new Random();
        boolean same = true;
        try 
        {
            ResultSet rs = statement.executeQuery("SELECT question , correctanswer, a0, a1 ,a2,a3 FROM Question WHERE questionno =" + gm.getCurrentQuestion());
            if (rs.next()) 
            {
                int cAns = rs.getInt("correctanswer");
                for (int i = 0; i < ans.length; i++)
                {
                    ans[i] = Character.getNumericValue(rs.getString("a" + i).charAt(0));
                    gm.getChoices()[i] = "";
                }
                for (int i = 0; i < ans.length; i++)
                {
                    if (cAns == ans[i])
                    {
                        gm.getChoices()[i] = rs.getString("a" + (ans[i] - 1));
                    } else 
                    {
                        falseAns[i] = ans[i] - 1;
                    }
                }
                while (same) 
                {
                    int randIndexFalseAns = rand.nextInt(gm.getChoices().length);
                    if (randIndexFalseAns != cAns - 1)
                    {
                        int index = falseAns[randIndexFalseAns];
                        gm.getChoices()[randIndexFalseAns] = rs.getString("a" + index);
                        same = false;
                    }
                }
            }
        } catch (SQLException ex) 
        {
            Logger.getLogger(QuestionManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
