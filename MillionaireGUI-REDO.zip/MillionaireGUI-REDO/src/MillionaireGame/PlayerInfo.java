
package MillionaireGame;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class PlayerInfo {
    //base class for players
    
    private String name;
    private Integer totalMoney;
    
    //constructor
    PlayerInfo(String name , Integer money){
        this.name = name;
        this.totalMoney = money;
    }

    //get and set
    public Integer getMoney() {
        return totalMoney;
    }

    public void setMoney(Integer money) {
        this.totalMoney = money;
    }
     public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



}