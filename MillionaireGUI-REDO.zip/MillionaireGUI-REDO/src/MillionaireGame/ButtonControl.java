package MillionaireGame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */

//this class sets actions for button
public class ButtonControl implements ActionListener {
    
    public DatabaseManager dbManager;
    public UImanager ui;

    //constructor
    public ButtonControl(UImanager ui, DatabaseManager dbm) {
        this.ui = ui;
        this.dbManager = dbm;
        this.ui.setActionListener(this);
    }

    @Override
    @SuppressWarnings( "deprecation" )
    public void actionPerformed(ActionEvent e) {
        String username;
        String password;
        String command = e.getActionCommand();

        //button actions
        switch (command) {
            //login and user buttons
            case "Log in":
                //login button 
                username = this.ui.getUsernameInput().getText();
                password = this.ui.getPasswordInput().getText();
                this.dbManager.checkValidUsername(username, password);
                break;
                case "Create new user":
                //open create user panel
                this.ui.getMessage().setText("");
                this.ui.getUsernameInput().setText("");
                this.ui.getPasswordInput().setText("");
                this.ui.createNewUser();
                break;
            case "Create":
                //creates user account
                if (this.ui.getUsernameInput().getText().length() > 0 && this.ui.getPasswordInput().getText().length() > 0) {
                    username = this.ui.getUsernameInput().getText();
                    password = this.ui.getPasswordInput().getText();
                    this.dbManager.createNewUser(username, password);
                } else {
                    this.ui.getMessage().setText("Please input a username or password of length greater than 0");
                    this.ui.createNewUser();
                }
                break;
            default:
                this.dbManager.checkUserAnswer(command);
                this.ui.checkButtonState();
                break;
            case "Walk away":
                //walk away
                this.ui.setWalkedAway(this.ui.getWalkedAway()+1);
                this.dbManager.leaveGame();   
                break;
            //LifeLines and game buttons
            case "Pass":
                //gives another question
                this.dbManager.passQuestion();
                this.ui.checkButtonState();
                ui.passQuestion();
                break;
            case "50/50":
                //eliminate 2 answers lifeline
                this.dbManager.fiftyFiftyLifeline();
                this.ui.checkButtonState();
                ui.fiftyFifty();          
                break;
            case "Return":
                this.ui.disposeFrame();
                GameMain game = new GameMain();
                break;
        }
    }

}
