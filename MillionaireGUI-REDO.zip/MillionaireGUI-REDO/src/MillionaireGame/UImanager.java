package MillionaireGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class UImanager extends JFrame implements Observer {
//PANELS
    //Panels displaying different screens
    private final JPanel SignInPanel = new JPanel();
    private final JPanel gameQuestionPanel = new JPanel();
    private final JPanel createNewUserPanel = new JPanel();
    private final JPanel gameOverPanel = new JPanel();
//LABELS
    private final JLabel userNameIndicator = new JLabel("Username: ");
    private final JLabel passwordIndicator = new JLabel("Password: ");
    //set create user panel components
    private final JLabel createUnameIndicator = new JLabel("Set UserName");
    private final JLabel createPwordIndicator = new JLabel("Set Password");
    private final JLabel question = new JLabel("", JLabel.CENTER);
    private final JLabel message = new JLabel("Welcome! Please log in or create a new user to get started", JLabel.CENTER);
    private final JLabel welcome = new JLabel("Who Wants to Be a Millionaire", JLabel.CENTER);
    private final JLabel createUserTitleText = new JLabel("Create User", JLabel.CENTER);
    private final JLabel endMessage = new JLabel();
//FIELDS
    //user input fields
    private final JTextField usernameField = new JTextField(10);
    private final JPasswordField passwordField = new JPasswordField(10);
//BUTTONS
    //question buttons
    private final JButton ansOne = new JButton();
    private final JButton ansTwo = new JButton();
    private final JButton ansThree = new JButton();
    private final JButton ansFour = new JButton();
    //question buttons
    private final JButton fiftyFiftyButton = new JButton("50/50");
    private final JButton passQuestionButton = new JButton("Pass");
    private final JButton walkAwayButton = new JButton("Walk away");
    //login and account creation buttons
    private final JButton loginButton = new JButton("Log in");
    private final JButton createUserOptionButton = new JButton("Create new user");
    private final JButton createButton = new JButton("Create");
    private final JButton returnToSignInButton = new JButton("Return");
//VARIABLES
    private boolean started = false;
    private boolean fiftyfiftyUsed = false;
    private boolean passQuestionUsed = false;
    private int walkedAway = 0;
    //background 
    BufferedImage backgroundImage = ImageIO.read(new File("src/MillionaireGame/Bg.jpg"));
    JLabel picLabel = new JLabel(new ImageIcon(backgroundImage));

    
    public UImanager() throws IOException {

        this.SignInPanel.setLayout(null);
        this.gameQuestionPanel.setLayout(null);
        this.createNewUserPanel.setLayout(null);
        this.gameOverPanel.setLayout(null);
        
        //
        super.setTitle("WHO WANTS TO BE A MILLIONAIRE");
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setSize(1000, 600); // Set frame size
        super.setLocationRelativeTo(null);
        super.setResizable(false); //non resizeable frame
        //question answer buttons
        ansOne.setFocusable(false);
        ansTwo.setFocusable(false);
        ansThree.setFocusable(false);
        ansFour.setFocusable(false);
        //lifeline buttons
        this.walkAwayButton.setFocusable(false);
        this.fiftyFiftyButton.setFocusable(false);
        this.passQuestionButton.setFocusable(false);
        //other buttons
        this.returnToSignInButton.setFocusable(false);
        this.createButton.setFocusable(false);
        this.createUserOptionButton.setFocusable(false);

//set bounds
        //login screen
        this.createButton.setBounds(420, 190, 160, 50);
        this.userNameIndicator.setBounds(270, 110, 70, 20);
        this.userNameIndicator.setForeground(Color.white);
        this.passwordIndicator.setBounds(270, 140, 70, 20);
        this.passwordIndicator.setForeground(Color.white);
        //
        this.loginButton.setBounds(425, 173, 150, 40);
        this.createUserOptionButton.setBounds(425, 220, 150, 40);
        this.createUnameIndicator.setBounds(250, 111, 90, 20);
        this.createUnameIndicator.setForeground(Color.white);
        this.createPwordIndicator.setBounds(250, 143, 90, 20);
        this.createPwordIndicator.setForeground(Color.white);
        //create panel
        //login panel
        this.message.setBounds(250, 80, 500, 20);
        this.message.setForeground(Color.white);
        //title text
        this.welcome.setBounds(250, 30, 500, 20);
        this.welcome.setFont(new Font("Courier", Font.BOLD | Font.ITALIC, 20));
        this.welcome.setForeground(Color.white);
        //new user
        this.createUserTitleText.setBounds(350, 30, 300, 20);
        this.createUserTitleText.setFont(new Font("Courier", Font.BOLD | Font.ITALIC, 20));
        this.createUserTitleText.setForeground(Color.white);
        //background
        this.picLabel.setBounds(0, 0, 1000, 600);
        this.picLabel.setIcon(new ImageIcon(backgroundImage.getScaledInstance(1000, 600, Image.SCALE_SMOOTH)));
        //question bounds
        this.question.setBounds(50, 120, 890, 60);
        this.question.setForeground(Color.cyan);
        this.question.setFont(new Font("Courier", Font.BOLD | Font.ITALIC, 16));
        this.question.setBorder(new LineBorder(Color.white, 8));
        //question answers
        this.ansOne.setBounds(480, 313, 220, 35);
        this.ansTwo.setBounds(240, 313, 220, 35);
        this.ansThree.setBounds(480, 368, 220, 35);
        this.ansFour.setBounds(240, 368, 220, 35);
        //lifelines
        this.walkAwayButton.setBounds(800, 500, 100, 40);
        this.fiftyFiftyButton.setBounds(370, 10, 100, 40);
        this.passQuestionButton.setBounds(490, 10, 100, 40);
        //other buttons
        this.SignInPanel.add(this.message);
        this.returnToSignInButton.setBounds(800, 500, 80, 40);

        this.userLogin();
    }
    //first display screen, user sign in panel
    public void userLogin() {
        this.passwordIndicator.setText("Password: ");
        this.userNameIndicator.setText("Username: ");
        //add components to panel
        this.SignInPanel.add(userNameIndicator);
        this.SignInPanel.add(usernameField);
        this.SignInPanel.add(passwordIndicator);
        this.SignInPanel.add(passwordField);
        this.SignInPanel.add(loginButton);
        this.SignInPanel.add(createUserOptionButton);
        this.SignInPanel.add(this.message);
        this.SignInPanel.add(this.welcome);
        this.SignInPanel.add(picLabel);
        
        this.usernameField.setBounds(350, 110, 300, 25);
        this.passwordField.setBounds(350, 140, 300, 25);
        //save panel
        this.getContentPane().removeAll();
        this.getContentPane().add(SignInPanel);
        this.setVisible(true);
        this.repaint();
        this.revalidate();
    }

    //sets action listener to all interactable java components
    public void setActionListener(ActionListener listener) {
        //sign in panel buttons
        this.loginButton.addActionListener(listener);
        //question panel buttons
        this.ansOne.addActionListener(listener);
        this.ansTwo.addActionListener(listener);
        this.ansThree.addActionListener(listener);
        this.ansFour.addActionListener(listener);
        //
        this.walkAwayButton.addActionListener(listener);
        this.fiftyFiftyButton.addActionListener(listener);
        this.passQuestionButton.addActionListener(listener);
        //account creation panel buttons
        this.createUserOptionButton.addActionListener(listener);
        this.createButton.addActionListener(listener);
        this.returnToSignInButton.addActionListener(listener);

    }
    //question screen where player plays millionaire game
    public void questionScreen() {
        //add j components
        gameQuestionPanel.add(walkAwayButton);
        gameQuestionPanel.add(fiftyFiftyButton);
        gameQuestionPanel.add(passQuestionButton);
        gameQuestionPanel.add(question);
        gameQuestionPanel.add(ansOne);
        gameQuestionPanel.add(ansTwo);
        gameQuestionPanel.add(ansThree);
        gameQuestionPanel.add(ansFour);
        //buttons
        this.ansOne.setActionCommand("1");
        this.ansTwo.setActionCommand("2");
        this.ansThree.setActionCommand("3");
        this.ansFour.setActionCommand("4");
        
        this.gameQuestionPanel.add(picLabel);

        this.getContentPane().removeAll();
        gameQuestionPanel.setVisible(true);
        this.add(gameQuestionPanel);
        //
        this.repaint();
        this.revalidate();
    }

    //control buttons for lifelines and avaiable lifelines
    public void checkButtonState() {
        //disable lifelines onced used and set to false
        if (this.passQuestionUsed == false) {
            this.passQuestionButton.setEnabled(true);
        }
        if (this.fiftyfiftyUsed == false) {
            this.fiftyFiftyButton.setEnabled(true);
        }
        if (ansOne.getText().isEmpty()) {
            ansOne.setEnabled(false);
        } else {
            ansOne.setEnabled(true);
        }
        if (ansTwo.getText().isEmpty()) {
            ansTwo.setEnabled(false);
        } else {
            ansTwo.setEnabled(true);
        }
        if (ansThree.getText().isEmpty()) {
            ansThree.setEnabled(false);
        } else {
            ansThree.setEnabled(true);
        }
        if (ansFour.getText().isEmpty()) {
            ansFour.setEnabled(false);
        } else {
            ansFour.setEnabled(true);
        }

    }

    public void setQuestion(String question, String[] choices, int questionNumber) {
        this.question.setText("Q" + questionNumber + ": " + question);

        this.ansOne.setText(choices[0]);
        this.ansTwo.setText(choices[1]);
        this.ansThree.setText(choices[2]);
        this.ansFour.setText(choices[3]);

    }
    //create user screen
    public void createNewUser() {
        //feilds for user input
        this.usernameField.setBounds(350, 110, 300, 25);
        this.passwordField.setBounds(350, 140, 300, 25);
        //add java components in panel
        this.createNewUserPanel.add(returnToSignInButton);
        this.createNewUserPanel.add(createUserTitleText);
        this.createNewUserPanel.add(createUnameIndicator);
        this.createNewUserPanel.add(usernameField);
        this.createNewUserPanel.add(createPwordIndicator);
        this.createNewUserPanel.add(passwordField);
        this.createNewUserPanel.add(createButton);
        this.createNewUserPanel.add(this.message);
        //
        this.getContentPane().removeAll();
        createNewUserPanel.setVisible(true);
        this.add(createNewUserPanel);
        this.createNewUserPanel.add(picLabel);
        this.repaint();
        this.revalidate();

    }

    //disable fiftyfifty lifeline after singel use
    public void fiftyFifty() {
        this.fiftyfiftyUsed = true;
        this.fiftyFiftyButton.setEnabled(false);

    }
    //disable pass question lifeline after 1 use
    public void passQuestion() {
        this.passQuestionUsed = true;
        this.passQuestionButton.setEnabled(false);
    }

    //closes jFrame
    public void disposeFrame() {
        super.dispose();
    }

    //sets game over screen
    private void gameOver(int money, int total) {
        JLabel gameOverTitle = new JLabel("Game Over");
        JLabel moneyWon = new JLabel("You leave with: " + money);
        JLabel acheivements = new JLabel("\n Total amount of money won on this account: " + total);

        //text bounds
        acheivements.setBounds(397, 60, 300, 15);
        acheivements.setForeground(Color.white);
        moneyWon.setBounds(400, 40, 300, 15);
        moneyWon.setForeground(Color.white);
        
        gameOverTitle.setBounds(440, 210, 600, 20);
        gameOverTitle.setFont(new Font("Courier", Font.BOLD | Font.ITALIC, 20));
        gameOverTitle.setForeground(Color.white);
        
        this.endMessage.setBounds(400, 20, 500, 15);
        this.endMessage.setForeground(Color.white);

        //add java components to panel
        gameOverPanel.add(this.endMessage);
        gameOverPanel.add(moneyWon);
        gameOverPanel.add(acheivements);
        gameOverPanel.add(returnToSignInButton);
        gameOverPanel.add(gameOverTitle);
        gameOverPanel.add(picLabel);
        this.getContentPane().removeAll();
        //
        this.add(gameOverPanel);
        gameOverPanel.setVisible(true);
        this.repaint();
        this.revalidate();
    }
    
    //update method is called constantly
    //update method updates messages according to GameManager changes and variables
    @Override
    public void update(Observable o, Object arg) {
        GameManager gManager = (GameManager) arg;
        if (!gManager.getCheck()) {
            //if player is trying to log in
            if (!gManager.getHasLogin()) {
                //changes message
                this.message.setText("Invalid username or password.");
                //clears out fields
                this.usernameField.setText("");
                this.passwordField.setText("");
            //if player is trying to create account
            } else if (gManager.userAlreadyExists) {
                //clears fields
                this.usernameField.setText("");
                this.passwordField.setText("");
                //changes message
                this.message.setText("Username is taken, please enter another username");
                this.createNewUser();
            //user account created, go back to sign in
            } else {
                this.usernameField.setText("");
                this.passwordField.setText("");
                this.message.setText("User account created");
                this.userLogin();
            }
        } else if (gManager.getHasQuit()) {
            //if player reaches the final question
            if(gManager.getCurrentQuestion() == 16){
                this.endMessage.setText("You have won WHO WANTS TO BE A MILLIONAIRE!");
            }
            //player loses
            if (!gManager.getCorrect()) {
                this.endMessage.setText("You chose the wrong");
            //player walks away with money
            } else if(this.getWalkedAway() == 1){
                this.endMessage.setText("You chose to walk away");
            }
            //save game
            this.gameOver(gManager.getCurrentMoney(), gManager.getTotalMoney());      
        //come back to starting screen, return was pressed
        } else if (!this.started) {
            this.questionScreen();
            this.started = true;
            this.setQuestion(gManager.getQuestion(), gManager.getChoices(), gManager.getCurrentQuestion());
        } else {
            this.setQuestion(gManager.getQuestion(), gManager.getChoices(), gManager.getCurrentQuestion());
        }
    }
//get and set methods
    public void setStarted(boolean started) {
        this.started = started;
    }
    public boolean isStarted() {
        return started;
    }
     public int getWalkedAway() {
        return walkedAway;
    }
    public void setWalkedAway(int walkedAway) {
        this.walkedAway = walkedAway;
    }    
    public JLabel getMessage() {
        return message;
    }
    public void setFiftyFiftyCounter(boolean ffu) {
        this.fiftyfiftyUsed = ffu;
    }
    public JTextField getUsernameInput() {
        return usernameField;
    }

    public JPasswordField getPasswordInput() {
        return passwordField;
    }
}
