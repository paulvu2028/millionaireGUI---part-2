package MillionaireGame;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class GameManager {
    //GameManager Class holds variables which control state of game
    private boolean hasLogin, hasQuit, correct, check;
    
    public boolean userAlreadyExists;
    private int totalMoney;
    private int currentQuestion;
    private int currentMoney;
    private int correctAns;

    private String question;
    private String[] questionChoices;

    //constuctor
    public GameManager() {
 
        this.questionChoices = new String[4];
        this.question = null;
        this.correct = true;
        this.userAlreadyExists = false;
        this.check = false;
        this.hasLogin = false;
        this.hasQuit = false;
        
        this.currentMoney = 0;
        this.correctAns = 0;
        this.totalMoney = 0;
        this.currentQuestion = 1;
    }
    
    //get and set methods
    public boolean getHasLogin() {
        return hasLogin;
    }

    public void setHasLogin(boolean hasLogin) {
        this.hasLogin = hasLogin;
    }

    public boolean getHasQuit() {
        return hasQuit;
    }

    public void setHasQuit(boolean hasQuit) {
        this.hasQuit = hasQuit;
    }
    
    public void setCurrentQuestion(int currentQuestion) {
        this.currentQuestion = currentQuestion;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String[] getChoices() {
        return questionChoices;
    }

    public void setChoices(String[] choices) {
        this.questionChoices = choices;
    }


    public boolean getCorrect() {
        return correct;
    }

    public void setCorrect(boolean correct) {
        this.correct = correct;
    }



    public int getCurrentMoney() {
        return currentMoney;
    }

    public void setCurrentMoney(int currentMoney) {
        this.currentMoney = currentMoney;
    }

    public boolean getCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }
    public int getCorrectAns() {
        return correctAns;
    }

    public void setCorrectAns(int correctAns) {
        this.correctAns = correctAns;
    }

    public int getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(int totalMoney) {
        this.totalMoney = totalMoney;
    }

    public int getCurrentQuestion() {
        return currentQuestion;
    }


}
