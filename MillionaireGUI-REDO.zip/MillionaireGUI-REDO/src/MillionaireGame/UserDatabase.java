package MillionaireGame;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class UserDatabase {

    //playerDatabase class connects to player database
    Connection conn = null;
    String url = "jdbc:derby:PlayerDB;create=true";
    String playerDbUsername = "pdc";
    String playerDbPassword = "pdc";
    Statement statement = null;

    public void playerDbSetup() {
        try {
            conn = DriverManager.getConnection(url, playerDbUsername, playerDbPassword);
            statement = conn.createStatement();
            String tableName = "UserInfo";

            if (!existingTable(tableName)) {
                statement.executeUpdate("CREATE TABLE " + tableName + " (userid VARCHAR(20), password VARCHAR(20), money INT)");
            }
            statement.close();

        } catch (SQLException ex) {
            Logger.getLogger(UserDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //check for pre-existing account with same username
    public GameManager checkName(String username, String password) {
        GameManager data = new GameManager(); // Initialize an instance of GameManager.
        try {
            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery("SELECT userid, password, money FROM UserInfo "
                    + "WHERE userid = '" + username + "'");
            if (rs.next()) {
                String pass = rs.getString("password");
                if (password.compareTo(pass) == 0) {;
                    data.setHasLogin(true);
                    data.setCheck(true);
                } else {
                    data.setHasLogin(false);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }


    public GameManager newUser(String username, String password) {
        GameManager data = new GameManager();
        try {
            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery("SELECT userid FROM UserInfo "
                    + "WHERE userid = '" + username + "'");
            if (rs.next()) {
                data.userAlreadyExists = true;
            } else {
                statement.executeUpdate("INSERT INTO UserInfo " + "VALUES('" + username + "', '" + password + "', 0)");
                data.setCurrentMoney(0);
                data.userAlreadyExists = false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        data.setHasLogin(true);
        return data;
    }
    
    //check for existing table, returns boolean
    private boolean existingTable(String newTableName) {
        boolean flag = false;
        try {
            System.out.println("Scaning for tables");
            String[] types = {"TABLE"};
            DatabaseMetaData dbmd = conn.getMetaData();
            ResultSet rsDBMeta = dbmd.getTables(null, null, null, null);
            
            while (rsDBMeta.next()) {
                String tableName = rsDBMeta.getString("TABLE_NAME");
                if (tableName.compareToIgnoreCase(newTableName) == 0) {
                    System.out.println(tableName + "  table found");
                    flag = true;
                }
            }
            if (rsDBMeta != null) {
                rsDBMeta.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    //saves total money earnt by user to data base
    public int saveGame(int money, String username) {
        Statement statement;
        int total = 0;
        try {
            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery("SELECT money FROM UserInfo "
                    + "WHERE userid = '" + username + "'");
            if (rs.next()) {
                total = rs.getInt("money");
            }
            total = total + money;

            statement.executeUpdate("UPDATE UserInfo SET money=" + total + " WHERE userid='" + username + "'");

        } catch (SQLException ex) {
            Logger.getLogger(UserDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return total;
    }

}

