package MillionaireGame;

import java.util.Observable;

/**
 * @author Paul Vu 17981406, Peter Ho 17978553
 */
public class DatabaseManager extends Observable 
{
//DatabaseManager interacts with both player database and question database to update their variables
    
    public UserDatabase userDb;
    public QuestionManager qManager;
    public GameManager gManager;
    public String userName;
    public int[] prizes = {0, 100, 200, 300, 500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 125000, 250000, 500000, 1000000};
    boolean isCorrect = true;
    
    //constructor
    public DatabaseManager() 
    {
        this.userDb = new UserDatabase();
        this.userDb.playerDbSetup();
        this.qManager = new QuestionManager();
        this.qManager.databaseSetUp();
    }
    
    //check 
    public void checkUserAnswer(String answer) 
    {
        if (this.gManager.getCorrectAns() == Integer.parseInt(answer)) 
        {
            this.gManager.setCurrentMoney(this.prizes[gManager.getCurrentQuestion()]);
            gManager.setCurrentQuestion(gManager.getCurrentQuestion() + 1);
            this.setUpNextQuestion(gManager);
            if (gManager.getCurrentQuestion() == this.prizes.length) 
            {
                this.leaveGame();
            }
            this.setChanged();
            this.notifyObservers(this.gManager);
        } 
        else 
        {
            this.gManager.setCurrentMoney(this.prizes[gManager.getCurrentQuestion() - 1]);
            this.gManager.setCorrect(false);
            this.setChanged();
            this.leaveGame();
        }
    }
    
        
    //checks for correct creditials to login
    public void checkValidUsername(String username, String password) 
    {
        this.userName = username;
        this.gManager = this.userDb.checkName(username, password);
        if (gManager.getHasLogin()) 
        {
            this.setUpNextQuestion(this.gManager);
        }
        this.setChanged();
        this.notifyObservers(this.gManager);
    }
    
    //creates new user account
    void createNewUser(String username, String password) 
    {
        this.userName = username;
        this.gManager = this.userDb.newUser(username, password); 
        this.setChanged();
        this.notifyObservers(this.gManager);
    }

    public void setUpNextQuestion(GameManager data) 
    {
        this.qManager.newQuestion(data);
    }
    
    //gives the a new question
    public void passQuestion() 
    {
            this.gManager.setCurrentMoney(this.prizes[gManager.getCurrentQuestion()]);
            gManager.setCurrentQuestion(gManager.getCurrentQuestion() + 1);
            this.setUpNextQuestion(gManager);
            this.setChanged();
            this.notifyObservers(this.gManager);
    }

    //lifeline which removes 2 wrong answers
    public void fiftyFiftyLifeline() 
    {
        this.qManager.fiftyFifty(this.gManager);
        this.setChanged();
        this.notifyObservers(this.gManager);
    }

    //walk away
    public void leaveGame() 
    {
        int total = this.userDb.saveGame(this.gManager.getCurrentMoney(), this.userName);
        this.gManager.setTotalMoney(total);
        this.gManager.setHasQuit(true);
        this.setChanged();
        this.notifyObservers(this.gManager);
    }
}
